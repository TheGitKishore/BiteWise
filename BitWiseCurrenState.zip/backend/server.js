// server.js
import express from 'express';
import cors from 'cors';
import userRoute from './routes/usersroute.js'; // <-- note the .js extension (add files from routes folder)
import reviewRoute from './routes/reviewroute.js';
import membershipplanRoute from './routes/membershipplanroute.js';
import userprofiletypeRoute from './routes/userprofiletyperoute.js';
import foodintakeentryRoute from './routes/foodintakeentryroute.js';
import fooditemRoute from './routes/fooditemroute.js';
import exerciseentryRoute from './routes/exerciseentryroute.js';
import mealplanRoute from './routes/mealplanroute.js';
import recipeRoute from './routes/reciperoute.js';


// ? ADD THIS
import { initializeDatabases } from './routes/apiroute.js';

const app = express();

app.use(cors());
app.use(express.json());

// Routes
app.use('/api/users', userRoute);
app.use('/api/reviews', reviewRoute);
app.use('/api/membership-plans', membershipplanRoute);
app.use('/api/user-profile-types', userprofiletypeRoute);
app.use('/api/food-entries', foodintakeentryRoute);
app.use('/api/food-items', fooditemRoute);
app.use('/api/exercise-entries', exerciseentryRoute);
app.use('/api/meal-plans', mealplanRoute);
app.use('/api/recipes', recipeRoute);

// ? Initialize DB before server starts
const startServer = async () => {
  try {
    await initializeDatabases();   // ?? THIS IS WHAT YOU WERE MISSING

    app.listen(3000, () => {
      console.log('Server running on port 3000');
    });

  } catch (error) {
    console.error('Failed to start server:', error);
  }
};

startServer();
