import React, { useState, useCallback } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, StatusBar, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

import CreateAccountController from '../controller/CreateAccountController';

const controller = new CreateAccountController();

// Design Tokens
const C = {
  purple:      '#7C3AED',
  purpleLight: '#EDE9FE',
  dark:        '#111827',
  mid:         '#374151',
  body:        '#4B5563',
  subtle:      '#6B7280',
  white:       '#FFFFFF',
  border:      '#E5E7EB',
  bg:          '#F3F4F6',
  errorBg:     '#FEF2F2',
  errorBorder: '#FECACA',
  errorText:   '#DC2626',
};


// SUB-COMPONENTS

// NavBar
const NavBar = ({ onMenuPress }) => (
  <View style={nav.bar}>
    <View style={nav.brand}>
      <Text style={nav.icon}>🍴</Text>
      <Text style={nav.brandName}>BiteWise</Text>
    </View>
    <TouchableOpacity
      onPress={onMenuPress}
      style={nav.menuBtn}
      accessibilityRole="button"
      accessibilityLabel="Open menu"
    >
      <View style={nav.menuLine} />
      <View style={[nav.menuLine, { width: 18 }]} />
      <View style={nav.menuLine} />
    </TouchableOpacity>
  </View>
);

const nav = StyleSheet.create({
  bar: {
    flexDirection:     'row',
    alignItems:        'center',
    justifyContent:    'space-between',
    paddingHorizontal: 20,
    paddingVertical:   14,
    backgroundColor:   C.white,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  brand: {
    flexDirection: 'row',
    alignItems:    'center',
    gap:           6,
  },
  icon:      { fontSize: 20 },
  brandName: {
    fontSize:      20,
    fontWeight:    '800',
    color:         C.dark,
    letterSpacing: -0.3,
  },
  menuBtn: {
    padding:    6,
    gap:        4,
    alignItems: 'flex-end',
  },
  menuLine: {
    width:           22,
    height:          2.5,
    backgroundColor: C.dark,
    borderRadius:    2,
  },
});

// Labelled input with optional error box above it
const InputField = ({ label, value, onChangeText, placeholder, secureTextEntry, error, keyboardType }) => (
  <View style={inf.wrap}>
    <Text style={inf.label}>{label}</Text>
    {error ? (
      <View style={inf.errorBox}>
        <Text style={inf.errorText}>{error}</Text>
      </View>
    ) : null}
    <TextInput
      style={[inf.input, error && inf.inputError]}
      value={value}
      onChangeText={onChangeText}
      placeholder={placeholder}
      placeholderTextColor={C.subtle}
      secureTextEntry={secureTextEntry}
      keyboardType={keyboardType || 'default'}
      autoCapitalize="none"
      autoCorrect={false}
    />
  </View>
);

const inf = StyleSheet.create({
  wrap:       { marginBottom: 16 },
  label: {
    fontSize:     14,
    fontWeight:   '600',
    color:        C.dark,
    marginBottom: 6,
  },
  errorBox: {
    backgroundColor:   C.errorBg,
    borderWidth:       1,
    borderColor:       C.errorBorder,
    borderRadius:      8,
    paddingVertical:   8,
    paddingHorizontal: 12,
    marginBottom:      8,
  },
  errorText: {
    fontSize: 13,
    color:    C.errorText,
  },
  input: {
    backgroundColor:   C.bg,
    borderRadius:      8,
    paddingHorizontal: 14,
    paddingVertical:   12,
    fontSize:          15,
    color:             C.dark,
    borderWidth:       1,
    borderColor:       C.border,
  },
  inputError: {
    borderColor: C.errorBorder,
  },
});


// MAIN SCREEN

const CreateAccountScreen = ({ navigation }) => {
  const [username,        setUsername]        = useState('');
  const [email,           setEmail]           = useState('');
  const [password,        setPassword]        = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fieldErrors,     setFieldErrors]     = useState({});
  const [isLoading,       setIsLoading]       = useState(false);

  // UC #08 Step 2: user taps Create Account
  const handleCreateAccount = useCallback(async () => {
    setFieldErrors({});
    setIsLoading(true);

    const result = await controller.createAccount({
      username,
      email,
      password,
      confirmPassword,
    });

    setIsLoading(false);

    if (result.success) {
      // Step 5: navigate to LoginScreen with green success banner
      navigation.navigate('LoginScreen', { successMessage: result.message });
    } else {
      // Alt Flows 1a / 1b / 1c: highlight the relevant field
      if (result.field) {
        setFieldErrors({ [result.field]: result.message });
      }
    }
  }, [username, email, password, confirmPassword, navigation]);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor={C.white} />

      <NavBar onMenuPress={() => navigation.navigate('MainLandingScreen')} />

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.card}>
            <Text style={styles.title}>Create Account</Text>
            <Text style={styles.subtitle}>Join BiteWise and start your health journey</Text>

            {/* UC #08 Step 1 — inputs */}
            <InputField
              label="Username"
              value={username}
              onChangeText={setUsername}
              placeholder="Enter your username"
              error={fieldErrors.username}
            />

            <InputField
              label="Email"
              value={email}
              onChangeText={setEmail}
              placeholder="Enter your email"
              keyboardType="email-address"
              error={fieldErrors.email}
            />

            <InputField
              label="Password"
              value={password}
              onChangeText={setPassword}
              placeholder="Enter your password"
              secureTextEntry
              error={fieldErrors.password}
            />

            <InputField
              label="Confirm Password"
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              placeholder="Confirm your password"
              secureTextEntry
              error={fieldErrors.confirm}
            />

            {/* UC #08 Step 2: submit */}
            <TouchableOpacity
              style={[styles.btn, isLoading && styles.btnDisabled]}
              onPress={handleCreateAccount}
              activeOpacity={0.85}
              disabled={isLoading}
              accessibilityRole="button"
              accessibilityLabel="Create Account"
            >
              <Text style={styles.btnText}>
                {isLoading ? 'Creating Account...' : 'Create Account'}
              </Text>
            </TouchableOpacity>

            {/* Already have an account → LoginScreen (future sprint) */}
            <View style={styles.loginRow}>
              <Text style={styles.loginPrompt}>Already have an account? </Text>
              <TouchableOpacity onPress={() => navigation.navigate('LoginScreen')}>
                <Text style={styles.loginLink}>Log in</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

// Styles
const styles = StyleSheet.create({
  safe: {
    flex:            1,
    backgroundColor: C.bg,
  },
  scroll: {
    flexGrow:          1,
    justifyContent:    'center',
    paddingHorizontal: 16,
    paddingVertical:   32,
  },
  card: {
    backgroundColor: C.white,
    borderRadius:    16,
    padding:         24,
    borderWidth:     1,
    borderColor:     C.border,
    shadowColor:     '#000',
    shadowOffset:    { width: 0, height: 1 },
    shadowOpacity:   0.05,
    shadowRadius:    4,
    elevation:       2,
  },
  title: {
    fontSize:      24,
    fontWeight:    '800',
    color:         C.dark,
    letterSpacing: -0.3,
    marginBottom:  4,
  },
  subtitle: {
    fontSize:     14,
    color:        C.subtle,
    marginBottom: 24,
  },
  btn: {
    backgroundColor: C.purple,
    borderRadius:    10,
    paddingVertical: 15,
    alignItems:      'center',
    marginTop:       8,
    marginBottom:    16,
  },
  btnDisabled: {
    opacity: 0.6,
  },
  btnText: {
    fontSize:   16,
    fontWeight: '700',
    color:      C.white,
  },
  loginRow: {
    flexDirection:  'row',
    justifyContent: 'center',
    alignItems:     'center',
  },
  loginPrompt: {
    fontSize: 14,
    color:    C.subtle,
  },
  loginLink: {
    fontSize:   14,
    fontWeight: '600',
    color:      C.purple,
  },
});

export default CreateAccountScreen;
