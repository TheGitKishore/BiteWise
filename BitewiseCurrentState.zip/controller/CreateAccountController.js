// Normal Flow (UC #08)
//   1. User inputs username, email, password, confirm password
//   2. User submits form → boundary calls createAccount()
//   3. Controller passes all inputs to User.createAccount()
//   4. Entity handles all validation and creation internally
//   5. Controller returns entity result envelope to boundary
//
// Alt Flows are handled entirely inside User.createAccount()

import User from '../entity/User';

class CreateAccountController {
  constructor() {}

  async _safeCall(fn) {
    try {
      return await fn();
    } catch (error) {
      console.error('[CreateAccountController]', error);
      return {
        success: false,
        field:   null,
        message: 'Something went wrong. Please try again.',
      };
    }
  }

  // UC #08 Step 2-5
  // @param  {{ username: string, email: string, password: string, confirmPassword: string }}
  // @return {Promise<{ success: boolean, field: string|null, message: string }>}
  async createAccount({ username, email, password, confirmPassword }) {
    return this._safeCall(async () => {
      return await User.createAccount({ username, email, password, confirmPassword });
    });
  }
}

export default CreateAccountController;
