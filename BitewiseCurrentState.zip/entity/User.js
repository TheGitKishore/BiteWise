class User {
  constructor({
    userId           = null,
    username         = '',
    email            = '',
    passwordHash     = '',
    firstName        = '',
    lastName         = '',
    dateOfBirth      = null,
    gender           = '',      // 'male' | 'female' | 'other'
    profileType      = null,    // 'MEAL_PLANNER' | 'ATHLETE' | 'HEALTH_ORIENTED'
    role             = 'FREE',  // 'FREE' | 'PREMIUM' | 'CURATOR' | 'ADMIN'
    membershipPlanId = null,
    isActive         = true,
    createdAt        = null,
    updatedAt        = null,
  } = {}) {
    this.userId           = userId;
    this.username         = username;
    this.email            = email;
    this.passwordHash     = passwordHash;
    this.firstName        = firstName;
    this.lastName         = lastName;
    this.dateOfBirth      = dateOfBirth;
    this.gender           = gender;
    this.profileType      = profileType;
    this.role             = role;
    this.membershipPlanId = membershipPlanId;
    this.isActive         = isActive;
    this.createdAt        = createdAt;
    this.updatedAt        = updatedAt;
  }


  // STATIC VALIDATION METHODS
  // Each returns { valid: boolean, message: string }

  // @param  {string} username
  // @return {{ valid: boolean, message: string }}
  static validateUsername(username) {
    if (!username || username.trim().length === 0) {
      return { valid: false, message: 'Username is required.' };
    }
    if (username.trim().length < 3) {
      return { valid: false, message: 'Username must be at least 3 characters.' };
    }
    if (username.trim().length > 20) {
      return { valid: false, message: 'Username must be 20 characters or fewer.' };
    }
    if (!/^[a-zA-Z0-9_]+$/.test(username.trim())) {
      return { valid: false, message: 'Username can only contain letters, numbers and underscores.' };
    }
    return { valid: true, message: '' };
  }

  // @param  {string} email
  // @return {{ valid: boolean, message: string }}
  static validateEmail(email) {
    if (!email || email.trim().length === 0) {
      return { valid: false, message: 'Email is required.' };
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return { valid: false, message: 'Please enter a valid email address.' };
    }
    return { valid: true, message: '' };
  }

  // @param  {string} password
  // @return {{ valid: boolean, message: string }}
  static validatePassword(password) {
    if (!password || password.length === 0) {
      return { valid: false, message: 'Password is required.' };
    }
    if (password.length < 6) {
      return { valid: false, message: 'Password must be at least 6 characters.' };
    }
    return { valid: true, message: '' };
  }


  // STATIC DATA ACCESS METHODS

  // UC #08 Alt Flow 1a — checks whether a username is already taken.
  // TODO: replace with real API call:
  //   const res = await fetch(`/api/users/check-username?username=${username}`);
  //   const { available } = await res.json();
  //   return available;
  //
  // @param  {string} username
  // @return {Promise<boolean>}
  static async isUsernameAvailable(username) {
    const takenUsernames = ['admin', 'bitewise', 'xuanxuan'];
    return !takenUsernames.includes(username.trim().toLowerCase());
  }

  // UC #08 Steps 3-4 — validates all inputs then creates the account.
  // Uses this.* so subclasses (FreeUser, PremiumUser) can override
  // individual validators without breaking this flow.
  //
  // TODO: replace the create block with a real API call once backend is ready.
  //
  // @param  {{ username: string, email: string, password: string, confirmPassword: string }}
  // @return {Promise<{ success: boolean, field: string|null, message: string, user: User|null }>}
  static async createAccount({ username, email, password, confirmPassword }) {

    const usernameCheck = this.validateUsername(username);
    if (!usernameCheck.valid) {
      return { success: false, field: 'username', message: usernameCheck.message, user: null };
    }

    const emailCheck = this.validateEmail(email);
    if (!emailCheck.valid) {
      return { success: false, field: 'email', message: emailCheck.message, user: null };
    }

    const passwordCheck = this.validatePassword(password);
    if (!passwordCheck.valid) {
      return { success: false, field: 'password', message: passwordCheck.message, user: null };
    }

    // Alt Flow 1c: confirm password mismatch
    if (password !== confirmPassword) {
      return { success: false, field: 'confirm', message: 'Passwords do not match.', user: null };
    }

    // Alt Flow 1a: username already taken
    const available = await this.isUsernameAvailable(username);
    if (!available) {
      return { success: false, field: 'username', message: 'Username already exists', user: null };
    }

    // Step 4: all checks passed — construct the new user
    const newUser = new this({
      userId:    Date.now(),
      username:  username.trim(),
      email:     email.trim(),
      role:      'FREE',
      isActive:  true,
      createdAt: new Date().toISOString(),
    });

    return {
      success: true,
      field:   null,
      message: 'Account created successfully! Please log in.',
      user:    newUser,
    };
  }
}

export default User;
